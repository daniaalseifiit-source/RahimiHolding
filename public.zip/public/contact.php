<?php
// Prevent direct access to the script via browser URL if not a POST request
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Method Not Allowed"]);
    exit;
}

// Set headers for JSON response
header('Content-Type: application/json');

// Get the raw POST data from React
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// --- CONFIGURATION ---
// REPLACE THIS WITH YOUR ACTUAL COMPANY EMAIL
$to_email = "msgus@rahimiholding.com"; 
// Optional: Add a CC
$cc_email = ""; 
// ---------------------

// Extract and sanitize inputs
$name = isset($data['name']) ? strip_tags(trim($data['name'])) : '';
$email = isset($data['email']) ? filter_var(trim($data['email']), FILTER_SANITIZE_EMAIL) : '';
$subject = isset($data['subject']) ? strip_tags(trim($data['subject'])) : 'New Inquiry';
$message = isset($data['message']) ? strip_tags(trim($data['message'])) : '';
// Honeypot (anti-bot) field: if a bot fills it, silently reject
$honeypot = isset($data['hp']) ? trim($data['hp']) : '';

// Basic rate-limiting: reject if same IP submits within 30s
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rateFile = sys_get_temp_dir() . "/contact_rate_" . md5($ip);
if (file_exists($rateFile)) {
    $last = (int)file_get_contents($rateFile);
    if (time() - $last < 30) {
        http_response_code(429);
        echo json_encode(["status" => "error", "message" => "Too many requests. Please wait before trying again."]);
        exit;
    }
}

// Validation
$errors = [];

if (!empty($honeypot)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Bot detected."]);
    exit;
}

// Sanitize name and subject to prevent header injection and trim length
$name = preg_replace('/[\r\n]+/', ' ', $name);
$name = mb_substr($name, 0, 100);
$subject = preg_replace('/[\r\n]+/', ' ', $subject);
$subject = mb_substr($subject, 0, 150);
$message = mb_substr($message, 0, 2000);

if (empty($name)) {
    $errors[] = "Name is required.";
}

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Valid email is required.";
}

if (empty($message)) {
    $errors[] = "Message is required.";
}

if (strlen($message) > 2000) {
    $errors[] = "Message is too long.";
}

// If there are validation errors, return them
if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => implode(" ", $errors)]);
    exit;
}

// Email Construction
$email_subject = "Website Inquiry: $subject";

$email_body = "You have received a new message from your website contact form.\n\n";
$email_body .= "Name: $name\n";
$email_body .= "Email: $email\n";
$email_body .= "Subject: $subject\n\n";
$email_body .= "Message:\n$message\n";

// Email Headers
// Use a server-controlled From address to avoid header injection and SPF/DKIM issues
$from_address = 'no-reply@rahimiholding.com';
$headers = "From: Rahimi Holding <$from_address>\r\n";
// Set Reply-To to user email but sanitize CRLF from it
$email_sanitized = preg_replace('/[\r\n]+/', '', $email);
$headers .= "Reply-To: $email_sanitized\r\n";
if (!empty($cc_email)) {
    $headers .= "Cc: $cc_email\r\n";
}
$headers .= "X-Mailer: PHP/" . phpversion();

// Record this submission timestamp for basic rate limiting
@file_put_contents($rateFile, time());

// --- Sending strategy ---
// If SMTP config is provided via environment variables and PHPMailer is installed
// (recommended for reliable deliverability), prefer sending via SMTP. To enable:
// 1) Install PHPMailer on the server: `composer require phpmailer/phpmailer`
// 2) Ensure `vendor/autoload.php` is accessible from this script (it usually is when Composer is run at the project root)
// 3) Set environment variables in your hosting panel: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_SECURE (tls|ssl), SMTP_FROM (optional), SMTP_FROM_NAME (optional)

$sent = false;
$smtpHost = getenv('SMTP_HOST') ?: '';

if ($smtpHost && class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
    // Try to use PHPMailer with SMTP
    try {
        // If Composer's autoload is present, it will already have registered the class. We still try to require it as a safeguard.
        if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
            require_once __DIR__ . '/../vendor/autoload.php';
        }

        $mail = new PHPMailer\\PHPMailer\\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = $smtpHost;
        $mail->SMTPAuth = true;
        $mail->Username = getenv('SMTP_USER') ?: '';
        $mail->Password = getenv('SMTP_PASS') ?: '';
        $mail->SMTPSecure = getenv('SMTP_SECURE') ?: 'tls';
        $mail->Port = intval(getenv('SMTP_PORT') ?: 587);

        $smtpFrom = getenv('SMTP_FROM') ?: $from_address;
        $smtpFromName = getenv('SMTP_FROM_NAME') ?: 'Website';
        $mail->setFrom($smtpFrom, $smtpFromName);
        $mail->addAddress($to_email);
        if (!empty($cc_email)) $mail->addCC($cc_email);
        $mail->addReplyTo($email_sanitized);

        $mail->Subject = $email_subject;
        $mail->Body = $email_body;

        if ($mail->send()) {
            $sent = true;
        }
    } catch (Exception $e) {
        // Log and continue to fallback
        error_log('Contact SMTP error: ' . $e->getMessage());
        $sent = false;
    }
}

// Fallback to PHP mail() if SMTP/PHPMailer is not available or sending via SMTP failed
if (!$sent) {
    if (mail($to_email, $email_subject, $email_body, $headers)) {
        http_response_code(200);
        echo json_encode(["status" => "success", "message" => "Message sent successfully."]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Failed to send email. Server configuration issue."]);
    }
} else {
    http_response_code(200);
    echo json_encode(["status" => "success", "message" => "Message sent successfully."]);
}
?>