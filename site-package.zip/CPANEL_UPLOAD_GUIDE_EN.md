# 🚀 Rahimi Holding Website - cPanel Upload Guide

## 📁 Production Files Ready for Upload

All files in the **dist** folder are ready for cPanel deployment:

```
dist/
├── index.html              (Main page - React SPA)
├── robots.txt              (Search engine instructions)
├── sitemap.xml             (XML sitemap)
├── contact.php             (Contact form backend)
├── .htaccess               (Apache configuration)
├── assets/
│   └── index-DQLt56n6.js   (Minified JavaScript bundle)
└── public/                 (Media files & resources)
```

---

## 🔧 cPanel Upload Steps

### **Step 1: Access cPanel**
- URL: `https://yourdomain.com:2083` or `https://yourdomain.com/cpanel`
- Enter your cPanel credentials

### **Step 2: Open File Manager**
- From cPanel dashboard, click **File Manager**
- Navigate to **public_html** folder
- (Optional) Delete old files if replacing an existing site

### **Step 3: Upload Files**

**Option A: Direct Upload**
1. Inside **public_html**, click **Upload**
2. Select all files from `dist` folder:
   - `index.html`
   - `robots.txt`
   - `sitemap.xml`
   - `contact.php`
   - `.htaccess` (make sure Show Hidden Files is enabled)
   - Entire `assets` folder
3. Click **Upload Files**

**Option B: ZIP Upload (Faster)**
1. Compress all dist files into `dist.zip`
2. From File Manager, click **Upload** and select `dist.zip`
3. Right-click the ZIP → **Extract**
4. Move extracted files to **public_html**

### **Step 4: Configure .htaccess**

The `.htaccess` file is essential for React SPA routing:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>

# Cache busting for static assets
<FilesMatch "\.(js|css|jpg|jpeg|png|gif|ico|svg|woff|woff2|ttf|eot)$">
  Header set Cache-Control "public, max-age=31536000"
</FilesMatch>

<FilesMatch "\.html$">
  Header set Cache-Control "public, max-age=3600"
</FilesMatch>
```

---

## ✅ Verification Checklist

### **1. Test Main Routes**
```
https://yourdomain.com/
https://yourdomain.com/about
https://yourdomain.com/products
https://yourdomain.com/contact
https://yourdomain.com/blog
https://yourdomain.com/terms
```

### **2. Verify Contact Form**
- Navigate to `/contact`
- Fill and submit the form
- Email should be delivered to configured address

### **3. Check Sitemap**
```
https://yourdomain.com/sitemap.xml
```

### **4. Verify robots.txt**
```
https://yourdomain.com/robots.txt
```

---

## 🔐 Security Setup

### **1. Enable HTTPS**
- cPanel → **AutoSSL** or **Let's Encrypt**
- Ensure all traffic redirects to HTTPS

### **2. PHP Version**
- cPanel → **PHP Selector**
- Use PHP 8.2 or higher for best performance

### **3. File Permissions**
- HTML/JS files: `644`
- PHP files: `644`
- Folders: `755`
- (cPanel usually sets these automatically)

---

## 📋 Important Files

| File | Purpose |
|------|---------|
| `index.html` | React SPA entry point |
| `assets/index-*.js` | Minified React bundle |
| `.htaccess` | URL rewriting for SPA routing |
| `robots.txt` | SEO - search engine instructions |
| `sitemap.xml` | SEO - site map for indexing |
| `contact.php` | Backend form processing |

---

## ⚙️ Configuration Notes

1. **Media/Images** - Loaded from CDN via `CONTENT_BASE` (configured in constants.ts)
2. **File Size** - Total built size ~450KB (highly optimized)
3. **Browser Cache** - Clear cache after update: `Ctrl+Shift+Delete`
4. **Domain Setup** - If new domain, update DNS records to point to cPanel

---

## 🆘 Troubleshooting

| Issue | Solution |
|-------|----------|
| 404 errors on routes | Verify `.htaccess` present and `mod_rewrite` enabled |
| Contact form fails | Check `contact.php` permissions (644) and email config |
| Site is slow | Enable PHP caching or optimize images |
| 500 errors | Check PHP error logs in cPanel |
| HTTPS issues | Run AutoSSL or contact hosting provider |

---

## 📊 Project Summary

- **Framework:** React 18 + TypeScript
- **Build Tool:** Vite
- **Styling:** Tailwind CSS
- **Languages:** English, Persian, Arabic
- **Pages:** 7 (Home, About, Products, Blog, Contact, Terms, BlogPost)
- **SEO:** Optimized with sitemap, robots.txt, meta tags
- **Performance:** ~445KB minified & gzipped

---

## 📞 Support

For questions or issues:
- **Email:** Info@rahimiholding.com
- **Phone:** +968-91239037
- **Website:** https://rahimiholding.com

✅ **Website is ready for production deployment!**
