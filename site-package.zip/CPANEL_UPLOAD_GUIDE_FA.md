# 🚀 آپلود سایت رحیمی هولدینگ روی cPanel

## 📁 محتویات آماده برای آپلود

فایل‌های تولید شده در فولدر **dist** برای آپلود روی cPanel آماده هستند:

```
dist/
├── index.html              (صفحه اصلی)
├── robots.txt              (برای موتورهای جستجو)
├── sitemap.xml             (نقشه سایت)
├── contact.php             (فرم تماس)
├── .htaccess               (کنفیگ Apache)
├── assets/
│   └── index-DQLt56n6.js   (کد جاوا‌اسکریپت)
└── public/                 (فایل‌های فلزات)
```

---

## 🔧 مراحل آپلود (روش کنترل پنل cPanel)

### **1. وارد شدن به cPanel**
- آدرس: `https://yourdomain.com:2083` یا `https://yourdomain.com/cpanel`
- نام کاربری و رمز عبور را وارد کنید

### **2. فایل منیجر (File Manager)**
- از صفحه اصلی cPanel، **File Manager** را انتخاب کنید
- بر روی **public_html** کلیک کنید
- تمام فایل‌های موجود را حذف کنید (اختیاری - اگر سایت قدیمی دارید)

### **3. آپلود فایل‌ها**

**گزینه الف: آپلود مستقیم**
1. درون **public_html**، دکمه **Upload** را کلیک کنید
2. تمام فایل‌ها را از فولدر `dist` انتخاب کنید:
   - `index.html`
   - `robots.txt`
   - `sitemap.xml`
   - `contact.php`
   - `.htaccess`
   - پوشه `assets`
   - پوشه `public` (اگر موجود باشد)
3. کلیک کنید روی **Upload Files**

**گزینه ب: آپلود ZIP (سریع‌تر)**
1. فایل‌های dist را در ZIP فشرده کنید:
   ```
   dist.zip
   ```
2. از File Manager، **Upload** را کلیک کنید و `dist.zip` را آپلود کنید
3. روی فایل ZIP کلیک‌راست کنید → **Extract**
4. تمام فایل‌های استخراج‌شده را به پوشه **public_html** منتقل کنید

### **4. کنفیگ Apache (.htaccess)**

فایل `.htaccess` برای دوباره‌نویسی URL برای Single Page Application (SPA) نیاز دارد.

**تأیید اینکه .htaccess موجود است:**
- File Manager میں، تنظیمات را بررسی کنید: **Show Hidden Files** فعال باشد
- `.htaccess` باید در `public_html` باشد

**محتوای .htaccess:**
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>

# Cache busting برای assets
<FilesMatch "\.(js|css|jpg|jpeg|png|gif|ico|svg|woff|woff2|ttf|eot)$">
  Header set Cache-Control "public, max-age=31536000"
</FilesMatch>

<FilesMatch "\.html$">
  Header set Cache-Control "public, max-age=3600"
</FilesMatch>
```

---

## ✅ تأیید بعد از آپلود

### **1. بررسی دسترسی**
```
https://yourdomain.com/
https://yourdomain.com/about
https://yourdomain.com/products
https://yourdomain.com/contact
https://yourdomain.com/blog
https://yourdomain.com/terms
```

### **2. بررسی فرم تماس**
- به صفحه `/contact` بروید
- فرم تماس را پر کنید و ارسال کنید
- ایمیل باید به آدرس موجود در `contact.php` رسید

### **3. بررسی سایت‌مپ**
```
https://yourdomain.com/sitemap.xml
```

### **4. بررسی robots.txt**
```
https://yourdomain.com/robots.txt
```

---

## 🔐 تنظیمات امنیتی

### **1. فعال کردن HTTPS**
- cPanel → **AutoSSL** یا **Let's Encrypt** را فعال کنید
- تمام آپلود‌ها از طریق HTTPS انجام شود

### **2. تنظیمات PHP**
- اگر سایت کند است، PHP version را بررسی کنید
- cPanel → **PHP Selector** → نسخه 8.2+ استفاده کنید

---

## 📧 فایل‌های مهم

| فایل | توضیح |
|------|-------|
| `index.html` | صفحه اصلی SPA |
| `assets/index-*.js` | کد برنامه (Minified) |
| `.htaccess` | دوباره‌نویسی URL برای SPA |
| `robots.txt` | دستورات برای گوگل/بینگ |
| `sitemap.xml` | نقشه سایت XML |
| `contact.php` | Backend فرم تماس |

---

## ⚠️ نکات مهم

1. **فایل‌های فلزی (Media)** - تصاویر از CDN بارگذاری می‌شوند (مطابق CONTENT_BASE)
2. **محدودیت حجم** - اگر موارد بیشتری نیاز است، با هاست‌ر تماس بگیرید
3. **کش (Cache)** - بعد از آپلود، کش مرورگر را پاک کنید: `Ctrl+Shift+Delete`
4. **DNS** - اگر دامنه جدید است، DNS را به cPanel اشاره دهید

---

## 🆘 رفع مشکلات

| مشکل | حل |
|------|-----|
| صفحات 404 میپ ظاهر می‌شوند | `.htaccess` را بررسی کنید - `mod_rewrite` فعال باید باشد |
| فرم تماس کار نمی‌کند | اجازه‌های `contact.php` را بررسی کنید (755) |
| سایت کند است | PHP Cache را فعال کنید یا تصاویر را بهینه کنید |
| خطای 500 | خطاهای PHP را در `error_log` بررسی کنید |

---

## 📞 پشتیبانی

برای سوالات بیشتر:
- **ایمیل:** Info@rahimiholding.com
- **گوشی:** +968-91239037

✅ **سایت برای آپلود آماده است!**
