const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const constantsPath = path.join(ROOT, 'src', 'constants.ts');
const outPath = path.join(ROOT, 'public', 'sitemap.xml');
const robotsPath = path.join(ROOT, 'public', 'robots.txt');

const baseUrl = 'https://rahimiholding.com';

const file = fs.readFileSync(constantsPath, 'utf8');

// naive extraction of numeric ids for products and blogs
const productIds = Array.from(file.matchAll(/export const PRODUCTS:[\s\S]*?\n\s*\];/g))[0]?.[0]
  ?.match(/id:\s*(\d+)/g)
  ?.map(s => s.replace(/id:\s*/, '')) || [];

const blogIds = Array.from(file.matchAll(/export const BLOG_POSTS:[\s\S]*?\n\s*\];/g))[0]?.[0]
  ?.match(/id:\s*(\d+)/g)
  ?.map(s => s.replace(/id:\s*/, '')) || [];

const staticPaths = ['/', '/about', '/products', '/blog', '/contact'];

const allPaths = new Set([...staticPaths, ...productIds.map(id => `/products/${id}`), ...blogIds.map(id => `/blog/${id}`)]);

function makeUrlEntry(p) {
  const loc = `${baseUrl}${p}`;
  const lastmod = new Date().toISOString();
  return `  <url>\n    <loc>${loc}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>0.5</priority>\n    <xhtml:link rel="alternate" hreflang="en" href="${loc}" />\n    <xhtml:link rel="alternate" hreflang="fa" href="${loc}?lang=fa" />\n    <xhtml:link rel="alternate" hreflang="ar" href="${loc}?lang=ar" />\n  </url>`;
}

const header = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n`;

const footer = '\n</urlset>';

const body = Array.from(allPaths).map(makeUrlEntry).join('\n');

const sitemap = header + body + footer;

fs.writeFileSync(outPath, sitemap, 'utf8');
console.log('Wrote sitemap to', outPath);

const robots = `User-agent: *\nAllow: /\nSitemap: ${baseUrl}/sitemap.xml\n`;
fs.writeFileSync(robotsPath, robots, 'utf8');
console.log('Wrote robots.txt to', robotsPath);